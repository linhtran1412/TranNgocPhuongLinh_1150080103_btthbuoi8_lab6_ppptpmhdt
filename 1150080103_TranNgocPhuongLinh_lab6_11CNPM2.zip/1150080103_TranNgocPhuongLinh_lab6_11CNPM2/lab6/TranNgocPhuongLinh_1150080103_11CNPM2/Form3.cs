﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_11CNPM2
{
    public partial class Form3 : Form
    {
       
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\pppt-pmhdt-c#\lab6\TranNgocPhuongLinh_1150080103_11CNPM2\QuanLyBanSach.mdf"";Integrated Security=True";

        private SqlConnection sqlCon = null;

        public Form3()
        {
            InitializeComponent();
        }

        // ====== Helpers mở/đóng kết nối ======
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ====== Load danh sách NXB (dùng SP HienThiNXB) ======
        private void HienThiDanhSachNXB()
        {
            MoKetNoi();

            using (var cmd = new SqlCommand("HienThiNXB", sqlCon))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                using (var rd = cmd.ExecuteReader())
                {
                    lsvDanhSach.Items.Clear();
                    while (rd.Read())
                    {
                        var it = new ListViewItem(rd.GetString(0)); // MaXB
                        it.SubItems.Add(rd.GetString(1));           // TenXB
                        it.SubItems.Add(rd.GetString(2));           // DiaChi
                        lsvDanhSach.Items.Add(it);
                    }
                }
            }

            DongKetNoi();
        }

        // ====== Events ======
        private void Form3_Load(object sender, EventArgs e)
        {
            // tiêu đề form theo yêu cầu
            this.Text = "Trần Ngọc Phương Linh - 11CNPM2 - 1150080103";
            HienThiDanhSachNXB();
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;

            var sel = lsvDanhSach.SelectedItems[0];
            txtMaXB.Text = sel.SubItems[0].Text;  // KHÓA CHÍNH -> chỉ đọc
            txtTenXB.Text = sel.SubItems[1].Text;
            txtDiaChi.Text = sel.SubItems[2].Text;
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            string ma = txtMaXB.Text.Trim();
            string ten = txtTenXB.Text.Trim();
            string dc = txtDiaChi.Text.Trim();

            if (string.IsNullOrWhiteSpace(ma))
            {
                MessageBox.Show("Hãy chọn một dòng ở danh sách bên trái!");
                return;
            }
            if (string.IsNullOrWhiteSpace(ten) || string.IsNullOrWhiteSpace(dc))
            {
                MessageBox.Show("Tên NXB và Địa chỉ không được để trống!");
                return;
            }

            try
            {
                MoKetNoi();

                using (var cmd = new SqlCommand("CapNhatThongTin", sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@MaXB", SqlDbType.Char, 10).Value = ma;
                    cmd.Parameters.Add("@TenXB", SqlDbType.NVarChar, 100).Value = ten;
                    cmd.Parameters.Add("@DiaChi", SqlDbType.NVarChar, 500).Value = dc;

                    int n = cmd.ExecuteNonQuery();
                    MessageBox.Show(n > 0 ? "Cập nhật thành công!" : "Không tìm thấy Mã NXB để cập nhật.");
                }

                HienThiDanhSachNXB(); // refresh list
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi SQL: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
