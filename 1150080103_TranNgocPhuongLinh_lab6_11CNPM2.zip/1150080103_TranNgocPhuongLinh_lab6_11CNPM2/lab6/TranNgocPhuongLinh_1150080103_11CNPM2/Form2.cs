﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_11CNPM2
{
    public partial class Form2 : Form
    {
        // Chuỗi kết nối giống Form1 của bạn
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\pppt-pmhdt-c#\lab6\TranNgocPhuongLinh_1150080103_11CNPM2\QuanLyBanSach.mdf"";Integrated Security=True";

        // Đối tượng kết nối
        SqlConnection sqlCon = null;

        public Form2()
        {
            InitializeComponent();
        }

        // Mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // Đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // Hiển thị danh sách NXB (để nhìn thấy record mới)
        private void HienThiDanhSachNXB()
        {
            MoKetNoi();

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiNXB";   // SP danh sách
            sqlCmd.Connection = sqlCon;

            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while (reader.Read())
            {
                string ma = reader.GetString(0);
                string ten = reader.GetString(1);
                string dc = reader.GetString(2);

                ListViewItem lvi = new ListViewItem(ma);
                lvi.SubItems.Add(ten);
                lvi.SubItems.Add(dc);
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();

            DongKetNoi();
        }

        // Nút thêm nhà xuất bản (SP ThemDuLieu)
        private void btnThem_Click(object sender, EventArgs e)
        {
            string ma = txtMaXB.Text.Trim();
            string ten = txtTenXB.Text.Trim();
            string dc = txtDiaChi.Text.Trim();

            if (ma == "" || ten == "" || dc == "")
            {
                MessageBox.Show("Vui lòng nhập đủ Mã, Tên và Địa chỉ!");
                return;
            }

            try
            {
                MoKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "ThemDuLieu";  // SP thêm
                sqlCmd.Connection = sqlCon;

                SqlParameter p1 = new SqlParameter("@MaXB", SqlDbType.Char, 10);
                SqlParameter p2 = new SqlParameter("@TenXB", SqlDbType.NVarChar, 100);
                SqlParameter p3 = new SqlParameter("@DiaChi", SqlDbType.NVarChar, 500);
                p1.Value = ma; p2.Value = ten; p3.Value = dc;

                sqlCmd.Parameters.Add(p1);
                sqlCmd.Parameters.Add(p2);
                sqlCmd.Parameters.Add(p3);

                sqlCmd.ExecuteNonQuery();

                MessageBox.Show("Thêm nhà xuất bản thành công!");
                txtMaXB.Clear(); txtTenXB.Clear(); txtDiaChi.Clear();
                txtMaXB.Focus();

                HienThiDanhSachNXB(); // refresh danh sách
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601) // trùng khóa
            {
                MessageBox.Show("Mã NXB đã tồn tại, vui lòng nhập mã khác!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }
    }
}
