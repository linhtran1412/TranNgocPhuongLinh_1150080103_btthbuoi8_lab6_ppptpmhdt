﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_11CNPM2
{
    public partial class Form4 : Form
    {
        // Sửa đường dẫn .mdf nếu khác máy bạn
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\pppt-pmhdt-c#\lab6\TranNgocPhuongLinh_1150080103_11CNPM2\QuanLyBanSach.mdf"";Integrated Security=True";
        private SqlConnection sqlCon = null;

        public Form4()
        {
            InitializeComponent();
        }

        // ===== Kết nối =====
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ===== Load list NXB =====
        private void HienThiDanhSachNXB()
        {
            MoKetNoi();
            using (var cmd = new SqlCommand("HienThiNXB", sqlCon))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                using (var rd = cmd.ExecuteReader())
                {
                    lsvDanhSach.Items.Clear();
                    while (rd.Read())
                    {
                        var it = new ListViewItem(rd.GetString(0)); // MaXB
                        it.SubItems.Add(rd.GetString(1));           // TenXB
                        it.SubItems.Add(rd.GetString(2));           // DiaChi
                        lsvDanhSach.Items.Add(it);
                    }
                }
            }
            DongKetNoi();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }

        // ===== Xóa =====
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0)
            {
                MessageBox.Show("Hãy chọn 1 dòng trong danh sách để xóa!");
                return;
            }

            string ma = lsvDanhSach.SelectedItems[0].SubItems[0].Text;

            if (MessageBox.Show($"Bạn chắc chắn muốn xóa NXB có mã: {ma}?",
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                != DialogResult.Yes) return;

            try
            {
                MoKetNoi();
                using (var cmd = new SqlCommand("XoaNXB", sqlCon))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@MaXB", SqlDbType.Char, 10).Value = ma;
                    int n = cmd.ExecuteNonQuery();

                    MessageBox.Show(n > 0 ? "Xóa thành công!" : "Không tìm thấy Mã NXB để xóa!");
                }

                HienThiDanhSachNXB(); // refresh lại list
            }
            catch (SqlException ex) when (ex.Number == 547) // FK constraint
            {
                MessageBox.Show("Không thể xóa vì còn dữ liệu liên quan (ví dụ bảng Sách đang tham chiếu).",
                                "Lỗi ràng buộc", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
