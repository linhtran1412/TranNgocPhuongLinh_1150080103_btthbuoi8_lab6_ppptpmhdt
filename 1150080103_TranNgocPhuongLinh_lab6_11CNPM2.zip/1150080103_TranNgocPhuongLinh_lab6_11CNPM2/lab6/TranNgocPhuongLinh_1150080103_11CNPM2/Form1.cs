﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TranNgocPhuongLinh_1150080103_11CNPM2
{
    public partial class Form1 : Form
    {
        // Chuỗi kết nối: giữ nguyên đường dẫn .mdf của bạn
        private readonly string strCon =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\pppt-pmhdt-c#\lab6\TranNgocPhuongLinh_1150080103_11CNPM2\QuanLyBanSach.mdf"";Integrated Security=True";

        // Đối tượng kết nối
        private SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ===== Thực hành 1: Hiển thị danh sách nhà xuất bản =====
        private void HienThiDanhSachNXB()
        {
            MoKetNoi();

            // gọi SP HienThiNXB như thầy
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiNXB";
            sqlCmd.Connection = sqlCon;

            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();

            while (reader.Read())
            {
                // MaXB, TenXB, DiaChi
                string maXB = reader.GetString(0);
                string tenXB = reader.GetString(1);
                string diaChi = reader.GetString(2);

                var lvi = new ListViewItem(maXB);
                lvi.SubItems.Add(tenXB);
                lvi.SubItems.Add(diaChi);
                lsvDanhSach.Items.Add(lvi);
            }

            reader.Close();
            DongKetNoi();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();   // y như trong tài liệu
            txtMaXB.Focus();
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;

            ListViewItem lvi = lsvDanhSach.SelectedItems[0];
            string maXB = lvi.SubItems[0].Text;

            HienThiThongTinXBTheoMa(maXB);
        }

        // xem chi tiết theo mã — gọi SP HienThiChiTietNXB
        private void HienThiThongTinXBTheoMa(string maXB)
        {
            MoKetNoi();

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiChiTietNXB";
            sqlCmd.Connection = sqlCon;

            SqlParameter parMaXB = new SqlParameter("@MaXB", SqlDbType.Char, 10);
            parMaXB.Value = maXB;
            sqlCmd.Parameters.Add(parMaXB);

            SqlDataReader reader = sqlCmd.ExecuteReader();

            txtMaXB.Text = txtTenXB.Text = txtDiaChi.Text = "";
            if (reader.Read())
            {
                txtMaXB.Text = reader.GetString(0);
                txtTenXB.Text = reader.GetString(1);
                txtDiaChi.Text = reader.GetString(2);
            }

            reader.Close();
            DongKetNoi();
        }
    }
}
